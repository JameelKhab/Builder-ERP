from pathlib import Path
import re

root = Path(__file__).resolve().parent
src = (root/'build_report_revision2.py').read_text()
src = src.replace('REVISION 2', 'REVISION 3')
src = src.replace('page_no += 1\n', "page_no += 1\n c.bookmarkPage(f'page{page_no}')\n c.addOutlineEntry(title, f'page{page_no}', level=0, closed=False)\n")
src = src.replace('def table(headers, rows, widths=None):', 'def table(headers, rows, widths=None, padding=7):')
src = src.replace("('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),", "('TOPPADDING',(0,0),(-1,-1),padding),('BOTTOMPADDING',(0,0),(-1,-1),padding),")
src = src.replace("c.setTitle('JAKH ERP - Read-only construction workflow study')", "c.setTitle('JAKH ERP - Revised navigation and construction workflow study')")
src = src.replace("c.setSubject('Evidence-backed navigation, construction workflow coverage, and original rebuild priorities')", "c.setSubject('Revision 3: user journeys, complete primary-menu mapping and evidence-backed construction scope')")

# Old pages 2-26 move forward twelve pages. The old page 27 proposal is removed.
# Old pages 28-32 move forward eleven pages. Update only explicit page citations.
def bump(match):
    prefix, first, dash, last = match.groups()
    def shift(n):
        n=int(n)
        return n+12 if 2<=n<=26 else n+11 if n>=28 else n
    out=prefix+str(shift(first))
    if last: out+=dash+str(shift(last))
    return out

pat=r'(\b[Pp]ages?\s+(?:<b>)?)(\d+)(-)?(\d+)?'
src=re.sub(pat,bump,src)
src=src.replace('See pages 27 and 18.', 'See pages 27 and 30.')

start=src.index("begin('Rebuild around the project'")
end=src.index("begin('Navigation needs a new structure'")
src=src[:start]+'''begin('Simpler to use, rich in information', 'Revision 3 - a critical re-study of the navigation proposal, based on the earlier read-only construction audit.')
p('<b>The previous map was still too module-oriented.</b> Projects, Buying, Finance and Resources could all appear to be the right starting point for the same job. This revision gives project work one continuous home and gives specialists direct company-wide queues opening the same records.')
heading('The revised recommendation')
table(['Starting point','Purpose'],[
 ('My Work','What needs my action or decision, what I am waiting for, and where I resume.'),
 ('Tenders','Opportunity, tender, estimate, offer and award, with a clear project handoff.'),
 ('Projects','One workspace: Overview, Plan, Site, Buying, Costs & Contracts, Documents, Handover.'),
 ('Company','Visible directory for Buying, Finance, People, Assets & Fleet, Stores, Contacts & Catalogue, and Reports.'),
],[CW*.25,CW*.75])
p('Keep project, location, work item, owner and next action visible. A case continues through its stages; users do not repeatedly open the same tabs in successive modules. Detailed quantities, money, evidence and history remain available under clear labels.')
heading('What was checked in this re-study')
p('Mapped <b>all 42 current primary entries</b> and <b>all twelve requested capabilities</b>; walked twelve findability scenarios on paper; examined four difficult cross-team journeys; specified record behaviour, scope, search, permissions and validation gates. No staff usability test or executable prototype was used.')
heading('Read this first')
p('<b>Pages 2-5:</b> the recommended map and daily experience.<br/><b>Page 6:</b> exact homes for your twelve areas.<br/><b>Pages 7-8:</b> tender-to-handover and difficult journeys.<br/><b>Pages 9-11:</b> every current primary menu mapped.<br/><b>Pages 12-13:</b> findability checks and user-testing criteria.')
p('<b>Supporting study:</b> existing UI findings and screenshots, pages 14-22; capability existence/need and detail, pages 23-38; original-code scope and validation, pages 39-41; evidence and limits, pages 42-43. Pages 2-13 replace the previous candidate navigation proposal.','small')
p('<b>Status:</b> this revision reassesses the study, not the live application. Earlier observations remain dated 28 October 2026 and are not newly retested. It is a recommended information map, not proof of the best possible usability. No application source was copied or new ERP code built.','small')

exec((ROOT/'work/study/mapping_content.py').read_text())

''' + src[end:]
start=src.index("begin('A simpler structure to validate'")
end=src.index("begin('Define an original application'")
src=src[:start]+src[end:]

# Consistent definitions: targets proposed before testing, baseline still required.
src=src.replace('Set numerical targets after obtaining a real baseline; no staff usability test has yet been run.', 'Use the proposed targets on page 13, record a real baseline, and agree gates before testing; no staff usability test has yet been run.')
(root/'build_report.py').write_text(src)

ext = (root/'extension_content_revision2.py').read_text()
ext = re.sub(pat,bump,ext)
ext = ext.replace('Project -> Site & Quality', 'Project -> Site -> Quality & NCRs')
ext = ext.replace('Project -> Site -> Quality & NCRs waste register', 'Project -> Site -> Waste register')
ext = ext.replace('Resources -> Assets', 'Company -> Assets & Fleet')
ext = ext.replace('Project -> Commercial', 'Project -> Costs & Contracts')
ext = ext.replace('Buying provides cross-project queues', 'Company -> Buying provides cross-project queues')
(root/'extension_content.py').write_text(ext)
