from pathlib import Path
from decimal import Decimal as D
import json, hashlib, zipfile, re
from PIL import Image, ImageChops
from pypdf import PdfReader
from mapping_data import MENU_MAP, CAPABILITIES

root=Path(__file__).resolve().parents[2]
out=root/'outputs/jakh-study'
work=root/'work/study'
pdf_path=out/'JAKH-ERP-Read-Only-Study.pdf'
pdf=PdfReader(pdf_path)
assert len(pdf.pages)==len(pdf.outline)==53
texts=[' '.join(p.extract_text().split()) for p in pdf.pages]
for n,t in enumerate(texts,1):
    assert 'REVISION 4' in t,n
    assert '\ufffd' not in t,n
topics={44:'Multiple companies, one clear context',45:'Vendor currency follows the purchase',
46:'Currency: keep the four meanings clear',47:'One reporting system, several scopes',
48:'Every report starts with findings',49:'Examples of useful report summaries',
50:'AI where it helps construction work',51:'AI in buying, money and company work',
52:'AI controls and rollout',53:'Acceptance checks for the added scope'}
for n,title in topics.items():assert title in texts[n-1],(n,title)
assert 'pages 44-53' in texts[0]
assert 'pages 50-52' in texts[4]
assert 'No Odoo application-code dependency' in texts[38]
for n in [25,26,27,28,29,32,33,34,35,36,37,38]:
    assert 'Existence:' in texts[n-1] or n==37

# Reconcile the invented numerical acceptance examples, not live business data.
assert [D('40000')*D(x) for x in ['4.00','4.10','4.15','4.20']]==[160000,164000,166000,168000]
assert D('170000')-D('164000')==6000
assert D('168000')-D('166000')==2000
assert D('620000')+D('460000')==1080000
assert D('1080000')-D('1000000')==80000
assert D('80000')/D('1000000')*100==8
assert D('180000')-D('120000')==60000
assert D('6')/D('20')*100==30

links=[]
for page in pdf.pages:
    for a in page.get('/Annots',[]):
        uri=a.get_object().get('/A',{}).get('/URI')
        if uri:links.append(str(uri))
for fragment in ['ifrs.org/issued-standards','nist.gov/publications/artificial-intelligence-risk','genai.owasp.org/llmrisk/llm062025']:
    assert any(fragment in u for u in links),fragment

unchanged=[];changed=[]
for n in range(1,44):
    old=Image.open(work/f'render-revision3/page-{n:02d}.png').convert('RGB')
    new=Image.open(work/f'render-revision4/page-{n:02d}.png').convert('RGB')
    assert old.size==new.size
    # Header revision number changes on all pages. Compare everything below it.
    box=(0,72,old.width,old.height)
    different=ImageChops.difference(old.crop(box),new.crop(box)).getbbox()
    (changed if different else unchanged).append(n)
assert changed==[1,2,4,5,39],changed

inventory=out/'Navigation-inventory.txt'
text=inventory.read_text()
header='ADDED REQUIREMENTS - REVISION 4'
if header not in text:
    text+='''\n\nADDED REQUIREMENTS - REVISION 4\n28 October 2026. Scope extension only; no new live ERP inspection.\n\nThe 42 observed primary entries and the four-starting-point proposal remain.\nThe Company workspace follows an explicit legal-company selector.\n\n- Multi-company foundations (PDF page 44): separate ledgers, authority, bank\n  accounts, numbering and access; shared vendor identity with entity-specific\n  terms; explicit intercompany/shared-project records.\n- Vendor currencies (45-46): selected quote/agreement/preference precedence;\n  original and company-currency values; versioned FX; repricing and budget\n  checks; one legal entity, vendor and currency per purchase order.\n- Reporting (47): project, company and authorised group scope with the same\n  metric definitions, drill-down, source/rate versions and explicit eliminations.\n- Report findings (48-49): a summary above every report and in exports, driven\n  by the full filtered dataset and verified rules, with optional AI explanation.\n- AI placement (50-52): contextual search/explanations, document extraction\n  and reviewable drafts across construction and company work; predictive\n  features only after sufficient data and evaluated benefit.\n- Acceptance (53): entity/currency isolation, report reconciliation, summary\n  correctness, permission-preserving AI, failure handling and measurable value.\n\nThese are proposed original-ERP requirements, not verified existing features.\nNo ERP implementation or AI integration was performed in this revision.\n'''
    inventory.write_text(text)
observed=re.findall(r'^\d{2}\. (.*?): \d+ controls;',text,re.M)
assert [m[1] for m in MENU_MAP]==observed
assert len(CAPABILITIES)==12

manifest=work/'evidence/README.json'
data=json.loads(manifest.read_text())
data['report_revision']=4
data['revision_4_scope']='Requirements extension for multiple legal companies, vendor-based purchase currencies, scoped reports, rules-based report findings and contextual AI. No additional live ERP inspection or implementation. Primary references: IFRS IAS 21 overview, NIST Generative AI Profile, OWASP Excessive Agency; reviewed 28 October 2026.'
manifest.write_text(json.dumps(data,indent=2))
archive=out/'Source-evidence.zip'
with zipfile.ZipFile(archive) as z:files={n:z.read(n) for n in z.namelist()}
readmes=[n for n in files if n.endswith('README.json')]
assert len(readmes)==1
files[readmes[0]]=manifest.read_bytes()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,content in files.items():z.writestr(name,content)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None

qa={'revision':4,'pages':53,'outline_entries':53,'primary_entries_mapped':42,
'requested_construction_areas_mapped':12,'new_topic_pages':topics,
'invented_fx_and_summary_examples_reconciled':True,'source_links_verified':True,
'unchanged_body_pages_match_previously_reviewed_pixels':unchanged,
'modified_existing_pages':changed,'new_pages':list(range(44,54)),
'new_live_erp_audit':False,'erp_implementation':False,'ai_integration':False,
'visual_review':'Pending modified and added page inspection',
'pdf_sha256':hashlib.sha256(pdf_path.read_bytes()).hexdigest(),
'pdf_bytes':pdf_path.stat().st_size,'evidence_archive_entries':len(files)}
(work/'revision-4-qa.json').write_text(json.dumps(qa,indent=2))
print(json.dumps(qa,indent=2))
