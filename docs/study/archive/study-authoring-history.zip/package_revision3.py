from pathlib import Path
import json, re, zipfile
from pypdf import PdfReader
from PIL import Image, ImageOps, ImageDraw
from mapping_data import MENU_MAP, CAPABILITIES, WALKTHROUGHS

root=Path(__file__).resolve().parents[2]
out=root/'outputs/jakh-study'
work=root/'work/study'
inventory=out/'Navigation-inventory.txt'
text=inventory.read_text()
prefix='CONCRETE CONSOLIDATION MAPPING'
if prefix in text:
    (work/'Navigation-inventory-revision2.txt').write_text(text)
    start=text.index(prefix)
    end=text.index('NEXT VALIDATION QUESTIONS',start)
    lines=['REVISED NAVIGATION MAP - REVISION 3 PROPOSAL',
           'This replaces the earlier candidate grouping. Full explanation: PDF pages 2-13.',
           'Global: My Work | Tenders | Projects | Company.',
           'Within a project: Overview | Plan | Site | Buying | Costs & Contracts | Documents | Handover.',
           'Company directory: Buying | Finance | People | Assets & Fleet | Stores | Contacts & Catalogue | Reports.',
           'Administration is a separate utility. Contextual views open canonical records, not copies.',
           'The map is a proposal; no staff usability test or new live audit occurred in Revision 3.', '',
           'Current primary entry | Proposed home | Continuity rule', '']
    lines += [f'{n:02d}. {old}\n  Home: {home}\n  Rule: {rule}\n' for n,old,home,rule in MENU_MAP]
    text=text[:start]+'\n'.join(lines)+'\n'+text[end:]
    text=text.replace('Use the revised PDF pages 11-12 for all twelve existence/need mappings and\npages 13-26 for detailed requirements, owners, UI placement and validation.',
      'In the current Revision 3 PDF, pages 23-24 map existence/need and pages 25-38\nprovide detailed requirements. Page 6 shows their revised navigation homes.')
    inventory.write_text(text)

observed=re.findall(r'^\d{2}\. (.*?): \d+ controls;',text,re.M)
assert len(observed)==42
assert [m[1] for m in MENU_MAP] == observed
assert [m[0] for m in MENU_MAP] == list(range(1,43))
assert len(CAPABILITIES)==len(WALKTHROUGHS)==12

pdf=PdfReader(out/'JAKH-ERP-Read-Only-Study.pdf')
assert len(pdf.pages)==43
assert len(pdf.outline)==43
texts=[p.extract_text() for p in pdf.pages]
topic_pages={25:'1. NCR operations',26:'2. Asset management',27:'3. Payments & cash flow',
28:'4. Subcontracting management',29:'5. Cost analysis for each site item',32:'6. Waste management',
33:'7. Variations and change requests',34:'8. Programme & delay',35:'9. KPI management',
36:'10. Keeping records',37:'11. Approval workflow',38:'12. Tracking and transparency'}
for n,t in topic_pages.items(): assert t in texts[n-1],(n,t)
for i,t in enumerate(texts,1):
    assert 'REVISION 3' in t, i
    assert '\ufffd' not in t, i
assert 'A simpler structure to validate' not in '\n'.join(texts)
links=[]
for p in pdf.pages:
    for a in p.get('/Annots',[]):
        uri=a.get_object().get('/A',{}).get('/URI')
        if uri:links.append(str(uri))
for source in ['nngroup.com/articles/progressive-disclosure','w3.org/WAI/WCAG22','design-system.service.gov.uk/components/task-list','pauligle.gumroad.com/l/ncr-management-kit']:
    assert any(source in x for x in links),source

manifest=work/'evidence/README.json'
data=json.loads(manifest.read_text())
data['report_revision']=3
data['revision_3_scope']='Re-study of the existing report and navigation proposal; no new live ERP inspection. UI evidence remains from the earlier 28 October read-only sessions. Proposed mapping covers all 42 primary entries and twelve requested areas; no user testing or ERP implementation.'
manifest.write_text(json.dumps(data,indent=2))
archive=out/'Source-evidence.zip'
with zipfile.ZipFile(archive) as z:
    files={name:z.read(name) for name in z.namelist()}
readme_names=[x for x in files if x.endswith('README.json')]
assert len(readme_names)==1
files[readme_names[0]]=manifest.read_bytes()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,content in files.items():z.writestr(name,content)

# Contact sheets support checking unchanged evidence pages after repagination.
render=work/'render-revision3'
for begin in range(14,44,4):
    pages=list(range(begin,min(begin+4,44)))
    sheet=Image.new('RGB',(1440,2040),'#d9d9d9')
    for i,n in enumerate(pages):
        im=Image.open(render/f'page-{n:02d}.png').convert('RGB')
        im.thumbnail((704,996))
        sheet.paste(im,(8+(i%2)*720,8+(i//2)*1020))
    sheet.save(render/f'contact-{begin:02d}.png')

qa={'revision':3,'pages':len(pdf.pages),'outline_entries':len(pdf.outline),
    'primary_entries_mapped':len(MENU_MAP),'primary_labels_match_observed_inventory':True,
    'requested_areas_mapped':len(CAPABILITIES),'desk_walkthroughs':len(WALKTHROUGHS),
    'topic_pages':topic_pages,'reference_links_verified':True,
    'live_application_retested_in_this_revision':False,'user_testing_performed':False,
    'business_state_transitions_tested':False,'visual_review':'Pending completion'}
(work/'revision-3-qa.json').write_text(json.dumps(qa,indent=2))
print(json.dumps(qa,indent=2))
